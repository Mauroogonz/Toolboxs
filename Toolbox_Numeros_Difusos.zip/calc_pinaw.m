function PINAW = calc_pinaw(y_up, y_lw, y_t)

%% Calcular el PINAW segun lo intervalos superiores e inferiores y el valor real
% Recordar que en esta funcion, y_up, y_lw son los intervalos y se
% consideran conocidos

% PINAW = ...

end